var searchData=
[
  ['copyright_217',['Copyright',['../page_copyright.html',1,'index']]],
  ['create_20and_20modify_20fonts_218',['Create and Modify Fonts',['../page_font_utility.html',1,'index']]]
];
